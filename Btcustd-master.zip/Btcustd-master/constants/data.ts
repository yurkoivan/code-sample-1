


export const data = [
    {x: new Date(2016, 6, 1), open: 5, close: 10, high: 15, low: 0},
    {x: new Date(2016, 6, 2), open: 10, close: 15, high: 20, low: 5},
    {x: new Date(2016, 6, 3), open: 15, close: 20, high: 22, low: 10},
    {x: new Date(2016, 6, 4), open: 20, close: 10, high: 25, low: 7},
    {x: new Date(2016, 6, 5), open: 10, close: 8, high: 15, low: 5},
    // More data points...
    {x: new Date(2016, 6, 6), open: 8, close: 9, high: 9, low: 6},
    {x: new Date(2016, 6, 7), open: 9, close: 7, high: 15, low: 9},
    {x: new Date(2016, 6, 8), open: 7, close: 10, high: 10, low: 6},
    {x: new Date(2016, 6, 9), open: 10, close: 6, high: 11, low: 12},
    {x: new Date(2016, 6, 10), open: 6, close: 6, high: 6, low: 6}
];